<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All posts from DB</title>
</head>
<body>
    <p>
        <h1> All posts</h1>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($post->title); ?></h3>
        <h1><?php echo e($post->body); ?></h1>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </p>
    <?php echo e(url()->previous()); ?>

    <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Back</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\AttendanceCRM\resources\views/posts.blade.php ENDPATH**/ ?>