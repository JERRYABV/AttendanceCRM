-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2022 at 09:46 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendances`
--

CREATE TABLE `attendances` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `attendance_time` time NOT NULL DEFAULT '18:09:00',
  `attendance_date` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `time_in` time NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attendances`
--

INSERT INTO `attendances` (`id`, `user_id`, `attendance_time`, `attendance_date`, `status`, `time_in`, `created_at`, `updated_at`) VALUES
(14, 11, '07:05:12', '2019-12-08', 0, '00:00:00', '2019-12-08 17:05:13', '2019-12-08 17:05:13'),
(15, 1, '12:07:58', '2022-06-19', 0, '00:00:00', '2022-06-19 08:07:58', '2022-06-19 08:07:58'),
(17, 12, '17:52:48', '2022-07-03', 0, '21:52:48', '2022-07-03 13:52:48', '2022-07-03 13:52:48'),
(25, 17, '18:19:23', '2022-07-03', 0, '22:19:23', '2022-07-03 14:19:23', '2022-07-03 14:19:23');

-- --------------------------------------------------------

--
-- Table structure for table `checks`
--

CREATE TABLE `checks` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `attendance_time` datetime NOT NULL,
  `leave_time` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `latetimes`
--

CREATE TABLE `latetimes` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `duration` time NOT NULL,
  `latetime_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `latetimes`
--

INSERT INTO `latetimes` (`id`, `user_id`, `duration`, `latetime_date`, `created_at`, `updated_at`) VALUES
(1, 11, '06:05:12', '2019-12-08', '2019-12-08 17:05:12', '2019-12-08 17:05:12'),
(2, 1, '03:07:58', '2022-06-19', '2022-06-19 08:07:58', '2022-06-19 08:07:58'),
(3, 12, '08:48:24', '2022-07-03', '2022-07-03 13:48:24', '2022-07-03 13:48:24'),
(4, 12, '08:50:21', '2022-07-03', '2022-07-03 13:50:21', '2022-07-03 13:50:21'),
(5, 12, '08:52:48', '2022-07-03', '2022-07-03 13:52:48', '2022-07-03 13:52:48'),
(6, 16, '08:56:58', '2022-07-03', '2022-07-03 13:56:58', '2022-07-03 13:56:58'),
(7, 16, '08:59:47', '2022-07-03', '2022-07-03 13:59:47', '2022-07-03 13:59:47'),
(8, 17, '09:04:20', '2022-07-03', '2022-07-03 14:04:20', '2022-07-03 14:04:20'),
(9, 17, '09:06:16', '2022-07-03', '2022-07-03 14:06:16', '2022-07-03 14:06:16'),
(10, 17, '09:08:08', '2022-07-03', '2022-07-03 14:08:08', '2022-07-03 14:08:08'),
(11, 17, '09:09:15', '2022-07-03', '2022-07-03 14:09:15', '2022-07-03 14:09:15'),
(12, 17, '09:12:27', '2022-07-03', '2022-07-03 14:12:27', '2022-07-03 14:12:27'),
(13, 17, '09:19:23', '2022-07-03', '2022-07-03 14:19:23', '2022-07-03 14:19:23');

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE `leaves` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `leave_time` time NOT NULL DEFAULT '18:13:00',
  `leave_date` date NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leaves`
--

INSERT INTO `leaves` (`id`, `user_id`, `leave_time`, `leave_date`, `status`, `created_at`, `updated_at`) VALUES
(5, 11, '22:54:58', '2019-12-08', 0, '2019-12-08 20:54:58', '2019-12-08 20:54:58'),
(6, 16, '17:57:46', '2022-07-03', 0, '2022-07-03 13:57:46', '2022-07-03 13:57:46');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_12_02_141403_create_roles_table', 1),
(4, '2019_12_03_044741_create_schedules_table', 2),
(5, '2019_12_03_045452_create_attendances_table', 3),
(6, '2019_12_03_045912_create_latetimes_table', 4),
(7, '2019_12_03_045930_create_overtimes_table', 4),
(8, '2019_12_03_050030_create_leaves_table', 4),
(9, '2019_12_22_183558_create_checks_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `overtimes`
--

CREATE TABLE `overtimes` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `duration` time NOT NULL,
  `overtime_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `slug`, `name`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator ', NULL, '2019-12-02 22:00:00', '2019-12-02 22:00:00'),
(2, 'emp', 'Employee', NULL, '2019-12-02 22:07:00', '2019-12-02 22:07:00');

-- --------------------------------------------------------

--
-- Table structure for table `role_users`
--

CREATE TABLE `role_users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_users`
--

INSERT INTO `role_users` (`user_id`, `role_id`) VALUES
(1, 1),
(11, 2),
(12, 2),
(14, 2),
(16, 2),
(17, 2),
(18, 2);

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_in` time NOT NULL,
  `time_out` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `slug`, `time_in`, `time_out`, `created_at`, `updated_at`) VALUES
(9, 'FirstShift', '09:00:00', '18:00:00', '2022-06-19 07:28:22', '2022-06-19 07:28:22'),
(10, 'SecondShift', '13:00:00', '17:00:00', '2022-07-03 13:55:46', '2022-07-03 13:55:46'),
(11, 'ThirdShift', '18:00:00', '23:59:00', '2022-07-03 15:41:22', '2022-07-03 15:41:22');

-- --------------------------------------------------------

--
-- Table structure for table `schedule_users`
--

CREATE TABLE `schedule_users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `schedule_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `schedule_users`
--

INSERT INTO `schedule_users` (`user_id`, `schedule_id`) VALUES
(1, 9),
(11, 9),
(12, 9),
(14, 9),
(16, 9),
(17, 9),
(18, 10);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pin_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `pin_code`, `permissions`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'SUPERADMIN', 'IAMSUPERADDMINN007009@gmail.com', '$2y$10$UwMCUBGK5pgcowbzABQnLOuq5wiOew6gh8t2s/NLGVQAKbS3PGXSG', NULL, NULL, '$2y$10$OhPF3G7Lv1JZwAOazjCcW.Y6RCA5816u.pkJbGxDkjXQb9U77ARWa', NULL, '2021-12-03 07:30:52', '2022-06-19 08:07:36'),
(11, 'jerryAbraa', 'JerryAbra1@gmail.com', '$2y$10$3Qs0zyRL.wkkzy7FDIghg.cBxlT..T1wDHjdaqyx7aCwAsomOeRXu', NULL, NULL, '$2y$10$.mF8x44U9uDMCI2.Hz9vnOSdN0SWdFFO8M3imRv.6ASh.0pxwoAvy', NULL, '2019-12-08 13:03:34', '2022-06-21 11:55:59'),
(12, 'JERRY ABRAHAM VARGHESE', 'jerryabrahamvarghese@gmail.com', '$2y$10$UwMCUBGK5pgcowbzABQnLOuq5wiOew6gh8t2s/NLGVQAKbS3PGXSG', NULL, NULL, '$2y$10$OhPF3G7Lv1JZwAOazjCcW.Y6RCA5816u.pkJbGxDkjXQb9U77ARWa', NULL, '2022-06-19 07:56:44', '2022-06-19 07:56:44'),
(14, 'Laisaa', 'laisa123@gmail.com', '$2y$10$52LrY769GGa8ZLgyKDHc1O/8jhWczUb0QkP7pNvVB8wr/2MAlP4eW', NULL, NULL, '$2y$10$95KnSK2M/2sJbyuvxPIU4.reCPcyRISD/3n41joMTAKl3cM4OPgBy', NULL, '2022-06-21 11:56:37', '2022-06-21 11:56:37'),
(16, 'Martha', 'martha1234@gmail.com', '$2y$10$OvKt0E7.pgePFT9/fTIYwunzfgRJgiANjiLDW4JXxbQPk7durAGt2', NULL, NULL, '$2y$10$gI8TGgMYy8gC8lqMQtWBCuJBm/noOEqLgpYn0f9qcCzjooiu8yz9K', NULL, '2022-07-03 13:56:32', '2022-07-03 13:56:32'),
(17, 'Martha', 'marthamohan1234@gmail.com', '$2y$10$nRKKDkeM/UEv9JhIiwakhOe7K2ce/fm5ax4d1t7pxwmuFsLpICqCC', NULL, NULL, '$2y$10$m.swZL0gjnCbs9Rygwv.NubUC5ibR5kk/TwNb0YlQEGVoUTn.sopy', NULL, '2022-07-03 14:02:59', '2022-07-03 14:02:59'),
(18, 'MathewJohn', 'mathewjohn@gmail.com', '$2y$10$sfkZbB1U9c/uzIg2k1u8zeTcsBs9aooZge3lmRs2UHS/NA82DHSta', NULL, NULL, '$2y$10$GFt89hLZiXSOGsoyZeLIwuTipwi16xzUpd.LSv3aw9/dK9fI6E7a2', NULL, '2022-07-03 14:21:39', '2022-07-03 14:21:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendances`
--
ALTER TABLE `attendances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attendances_user_id_foreign` (`user_id`);

--
-- Indexes for table `checks`
--
ALTER TABLE `checks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `checks_user_id_foreign` (`user_id`);

--
-- Indexes for table `latetimes`
--
ALTER TABLE `latetimes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `latetimes_user_id_foreign` (`user_id`);

--
-- Indexes for table `leaves`
--
ALTER TABLE `leaves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leaves_user_id_foreign` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `overtimes`
--
ALTER TABLE `overtimes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `overtimes_user_id_foreign` (`user_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_slug_unique` (`slug`);

--
-- Indexes for table `role_users`
--
ALTER TABLE `role_users`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `role_users_role_id_foreign` (`role_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `schedules_slug_unique` (`slug`);

--
-- Indexes for table `schedule_users`
--
ALTER TABLE `schedule_users`
  ADD PRIMARY KEY (`user_id`,`schedule_id`),
  ADD KEY `schedule_users_schedule_id_foreign` (`schedule_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendances`
--
ALTER TABLE `attendances`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `checks`
--
ALTER TABLE `checks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `latetimes`
--
ALTER TABLE `latetimes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `leaves`
--
ALTER TABLE `leaves`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `overtimes`
--
ALTER TABLE `overtimes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendances`
--
ALTER TABLE `attendances`
  ADD CONSTRAINT `attendances_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `checks`
--
ALTER TABLE `checks`
  ADD CONSTRAINT `checks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `latetimes`
--
ALTER TABLE `latetimes`
  ADD CONSTRAINT `latetimes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `leaves`
--
ALTER TABLE `leaves`
  ADD CONSTRAINT `leaves_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `overtimes`
--
ALTER TABLE `overtimes`
  ADD CONSTRAINT `overtimes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_users`
--
ALTER TABLE `role_users`
  ADD CONSTRAINT `role_users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `schedule_users`
--
ALTER TABLE `schedule_users`
  ADD CONSTRAINT `schedule_users_schedule_id_foreign` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `schedule_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
