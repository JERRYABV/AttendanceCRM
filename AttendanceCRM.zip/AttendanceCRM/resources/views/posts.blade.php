<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All posts from DB</title>
</head>
<body>
    <p>
        <h1> All posts</h1>
    @foreach ($posts as $post )
        <h3>{{ $post->title }}</h3>
        <h1>{{ $post->body}}</h1>
    @endforeach
    </p>

    <a href="{{ URL::previous() }}">Go Back</a>
    <a href="{{ url()->previous() }}" class="btn btn-default">Back</a>
</body>
</html>
